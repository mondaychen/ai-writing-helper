export default function App() {
  return <div className="ceb-all-runtime-content-view-text">All runtime content view</div>;
}
