import { sampleFunction } from '@src/sample-function';

void sampleFunction();
